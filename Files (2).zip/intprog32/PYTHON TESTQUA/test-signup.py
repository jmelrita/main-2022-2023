from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service

chrome_options = Options()
chrome_options.add_experimental_option("detach", True)
driver = webdriver.Chrome(options=chrome_options)
driver.get("https://www.facebook.com/signup")

firstname = driver.find_element(by=By.NAME, value="firstname")
firstname.send_keys("Jun Mel")
lastname = driver.find_element(by=By.NAME, value="lastname")
lastname.send_keys("Rita")
email = driver.find_element(by=By.NAME, value="reg_email__")
email.send_keys("09999615706")
passwd = driver.find_element(by=By.NAME, value="reg_passwd__")
passwd.send_keys("1234567890")
bday = driver.find_element(by=By.NAME, value="birthday_month")
bday.send_keys("Jan")
bday2 = driver.find_element(by=By.NAME, value="birthday_day")
bday2.send_keys("15")
bday3 = driver.find_element(by=By.NAME, value="birthday_year")
bday3.send_keys("2000")
driver.find_element(By.XPATH,"//input[@value='2']").click()