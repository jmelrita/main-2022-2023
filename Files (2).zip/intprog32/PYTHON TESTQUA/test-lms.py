from selenium import webdriver
from selenium.webdriver.common.by import By


driver = webdriver.Chrome()
driver.get("https://universityofcebu.ethinksites.com/login/index.php")


driver.implicitly_wait(0.5)
username = driver.find_element(by=By.NAME, value="username")
username.send_keys("ucmn-19920511")

password = driver.find_element(by=By.NAME, value="password")
password.send_keys("Uc-062200")

loginbtn = driver.find_element("id","loginbtn")
loginbtn.submit()