<!DOCTYPE html>
<html>
<head>
	<Title>Decimal Converter</Title>
<body>
    <h2>Decimal to Binary Converter</h2>
    <form method="post">
        <label for="decimal">Enter a decimal value:</label>
        <input type="number" name="decimal" id="decimal" required>
        <input type="submit" value="Convert">
    </form>
	<?php
	function decimal_to_binary($decimal){		
	$binary_num = sprintf('%016b', $decimal);
	return $binary_num;
	}
	
	$decimal_num = readline("Enter the decimal number: ");

	$binary_num = decimal_to_binary($decimal);

	echo "The binary equivalent of $decimal is: $binary_num";
	?>
</body>
</html>