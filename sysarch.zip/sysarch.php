<!DOCTYPE html>
<html>
<head>
    <title>Decimal to Binary Converter</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        label {
            font-weight: bold;
        }
        input[type="submit"] {
            background-color: #4CAF50;
            border: none;
            color: white;
            padding: 12px 24px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 4px 2px;
            cursor: pointer;
        }
        .result {
            font-size: 24px;
            font-weight: bold;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <h1>Decimal to Binary Converter</h1>
    <form method="post">
        <label for="decimal">Enter a decimal value:</label>
        <input type="number" name="decimal" id="decimal" required>
        <input type="submit" value="Convert">
    </form>
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $decimal = $_POST["decimal"];
        $binary = decbin($decimal);
        echo "<div class='result'>The binary representation of $decimal is $binary</div>";
    }
    ?>
</body>
</html>