<?php
function decToBinary($n)
{
	for ( $i = 13; $i >= 0; $i--)
	{
		$k = $n >> $i;
		if ($k & 1)
			echo "1";
		else
			echo "0";
	}
}
	$n = 13;
	decToBinary($n);
?>
