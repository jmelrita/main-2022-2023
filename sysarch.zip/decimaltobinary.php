<html>
<head>
<title></title>
   
</head>
<body>
            <div class="nukr"><h2 class="col_insert" >Decimal to Binary Converter</h2></div>
                <form action="" method="post" name="insert_form" id="insert_form" class="comment-form">
                     <table class="tableI1" align="left" border="0" bordercolor="#000000" >
						<tr><td ><b>Enter Number</b></td>
							<td><input id="number" name="number" type="text" size="30" /> 
						<tr><td></td><td><center><input type="submit" id="btnsubmit" name="btnsubmit" value="Calculate" size="30"/></center></td></tr>
							<tr>
								<td>
									</td>	
										<td>
											</td>
												</tr>
                     </table>
                </form>
 
</body>
</html>
<?php
if(isset($_POST['btnsubmit']))
{
 
$number ;$conv=0;
$number=$_POST['number'];
echo "<br><br>";
echo "<br><br>";
echo"Decimal Number is : $number<br>";
$conv=decbin($number);
echo sprintf("Binary Number is: %016d",$conv);
 
}
?>	